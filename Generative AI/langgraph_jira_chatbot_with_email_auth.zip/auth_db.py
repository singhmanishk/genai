import sqlite3
import bcrypt
import datetime

DB_PATH = "auth.db"

def init_auth_db():
    conn = sqlite3.connect(DB_PATH)
    conn.execute("""
    CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY,
        username TEXT UNIQUE,
        email TEXT UNIQUE,
        hashed_password TEXT,
        is_verified BOOLEAN DEFAULT 0,
        created_at TEXT
    )
    """)
    conn.commit()
    conn.close()

def register_user(username, email, password, is_verified=False):
    conn = sqlite3.connect(DB_PATH)
    hashed = bcrypt.hashpw(password.encode(), bcrypt.gensalt()).decode()
    conn.execute(
        "INSERT INTO users (username, email, hashed_password, is_verified, created_at) VALUES (?, ?, ?, ?, ?)",
        (username, email, hashed, is_verified, datetime.datetime.now().isoformat())
    )
    conn.commit()
    conn.close()

def authenticate_user(email, password):
    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()
    cur.execute("SELECT hashed_password FROM users WHERE email = ?", (email,))
    row = cur.fetchone()
    conn.close()
    if row:
        return bcrypt.checkpw(password.encode(), row[0].encode())
    return False