import sqlite3

def register_user(email, password):
    conn = sqlite3.connect("chat_db/memory.sqlite")
    c = conn.cursor()
    c.execute("CREATE TABLE IF NOT EXISTS users (email TEXT PRIMARY KEY, password TEXT)")
    try:
        c.execute("INSERT INTO users (email, password) VALUES (?, ?)", (email, password))
    except sqlite3.IntegrityError:
        pass
    conn.commit()
    conn.close()

def login_user(email, password):
    conn = sqlite3.connect("chat_db/memory.sqlite")
    c = conn.cursor()
    c.execute("SELECT * FROM users WHERE email = ? AND password = ?", (email, password))
    result = c.fetchone()
    conn.close()
    return result is not None

def logout_user():
    return True
