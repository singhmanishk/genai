import streamlit as st
from auth import login_user, logout_user, register_user
from db import get_user_sessions, save_chat_session
from router_graph import chatbot
import uuid

st.set_page_config(page_title="LangGraph Chatbot", layout="wide")

if "authenticated" not in st.session_state:
    st.session_state["authenticated"] = False
if "active_session" not in st.session_state:
    st.session_state["active_session"] = None
if "chat_history" not in st.session_state:
    st.session_state["chat_history"] = []

st.title("💬 LangGraph Chatbot")

if not st.session_state["authenticated"]:
    with st.form("login"):
        st.subheader("Login")
        email = st.text_input("Email")
        password = st.text_input("Password", type="password")
        if st.form_submit_button("Login"):
            if login_user(email, password):
                st.session_state["authenticated"] = True
                st.session_state["user_email"] = email
                st.success("Logged in successfully.")
            else:
                st.error("Invalid credentials")
    st.markdown("---")
    with st.form("register"):
        st.subheader("Register")
        new_email = st.text_input("New Email")
        new_password = st.text_input("New Password", type="password")
        if st.form_submit_button("Register"):
            register_user(new_email, new_password)
            st.success("Account created. You can now log in.")
else:
    st.sidebar.title("💬 Conversations")
    sessions = get_user_sessions(st.session_state["user_email"])
    for session in sessions:
        if st.sidebar.button(session["title"]):
            st.session_state["active_session"] = session["session_id"]
            st.session_state["chat_history"] = []

    if st.sidebar.button("➕ New Chat"):
        session_id = str(uuid.uuid4())
        st.session_state["active_session"] = session_id
        save_chat_session(st.session_state["user_email"], session_id, "New Chat")
        st.session_state["chat_history"] = []

    if st.sidebar.button("🚪 Logout"):
        logout_user()
        st.session_state["authenticated"] = False
        st.session_state.clear()
        st.experimental_rerun()

    if st.session_state.get("active_session"):
        user_input = st.chat_input("Type your message")
        for msg in st.session_state["chat_history"]:
            st.chat_message(msg["role"]).write(msg["content"])

        if user_input:
            st.session_state["chat_history"].append({"role": "user", "content": user_input})
            with st.chat_message("user"):
                st.write(user_input)

            response = chatbot.invoke({"user_input": user_input, "session_id": st.session_state["active_session"]})
            st.session_state["chat_history"].append({"role": "assistant", "content": response["final_output"]})

            with st.chat_message("assistant"):
                st.write(response["final_output"])
