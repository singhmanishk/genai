import sqlite3

def init_db():
    conn = sqlite3.connect("chat_db/memory.sqlite")
    c = conn.cursor()
    c.execute("""
    CREATE TABLE IF NOT EXISTS chat_sessions (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_email TEXT,
        session_id TEXT,
        title TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )
    """)
    c.execute("""
    CREATE TABLE IF NOT EXISTS users (
        email TEXT PRIMARY KEY,
        password TEXT
    )
    """)
    conn.commit()
    conn.close()

def get_user_sessions(user_email: str):
    conn = sqlite3.connect("chat_db/memory.sqlite")
    conn.row_factory = sqlite3.Row
    c = conn.cursor()
    c.execute("SELECT session_id, title FROM chat_sessions WHERE user_email = ? ORDER BY created_at DESC", (user_email,))
    sessions = c.fetchall()
    conn.close()
    return sessions

def save_chat_session(user_email: str, session_id: str, title: str):
    conn = sqlite3.connect("chat_db/memory.sqlite")
    c = conn.cursor()
    c.execute("INSERT INTO chat_sessions (user_email, session_id, title) VALUES (?, ?, ?)", (user_email, session_id, title))
    conn.commit()
    conn.close()
