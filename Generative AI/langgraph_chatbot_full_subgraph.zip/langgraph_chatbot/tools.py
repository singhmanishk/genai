def payment_tool(x: str) -> str:
    return "Fetching payment info for: " + x

def order_tool(x: str) -> str:
    return "Fetching order info for: " + x
