from langchain.memory.chat_message_histories import SQLChatMessageHistory
from langchain.memory import ConversationBufferMemory

def get_memory(session_id: str):
    return ConversationBufferMemory(
        memory_key="chat_history",
        return_messages=True,
        chat_memory=SQLChatMessageHistory(
            session_id=session_id,
            connection_string="sqlite:///chat_db/memory.sqlite"
        )
    )
