from langgraph.graph import StateGraph
from typing import TypedDict
from langchain.agents import Tool, initialize_agent
from langchain.chat_models import ChatOpenAI
from memory import get_memory
from tools import payment_tool, order_tool

class ParentState(TypedDict):
    user_input: str
    session_id: str
    final_output: str

def build_agent(session_id, tools):
    llm = ChatOpenAI(model="gpt-4o")
    memory = get_memory(session_id)
    agent = initialize_agent(tools, llm, memory=memory, agent="chat-conversational-react-description")

    def node(state: ParentState) -> ParentState:
        response = agent.run(state["user_input"])
        return {"user_input": state["user_input"], "session_id": state["session_id"], "final_output": response}

    graph = StateGraph(ParentState)
    graph.add_node("agent", node)
    graph.set_entry_point("agent")
    graph.set_finish_point("agent")
    return graph.compile()

# Define tools and agents
payment_agent = build_agent("payment", [Tool("Payment", payment_tool, "")])
order_agent = build_agent("order", [Tool("Order", order_tool, "")])
general_agent = build_agent("general", [])

# Parent router graph
def router_node(state: ParentState) -> str:
    if "payment" in state["user_input"].lower():
        return "payment_agent"
    elif "order" in state["user_input"].lower():
        return "order_agent"
    else:
        return "general_agent"

router = StateGraph(ParentState)
router.add_node("router", router_node)
router.add_node("payment_agent", lambda s: payment_agent.invoke(s))
router.add_node("order_agent", lambda s: order_agent.invoke(s))
router.add_node("general_agent", lambda s: general_agent.invoke(s))

router.set_entry_point("router")
router.add_conditional_edges("router", router_node)
router.set_finish_point("payment_agent")
router.set_finish_point("order_agent")
router.set_finish_point("general_agent")

chatbot = router.compile()
