import sqlite3
import bcrypt
from datetime import datetime
import pandas as pd

DB_PATH = "chat_history.db"

def init_db():
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute('''
        CREATE TABLE IF NOT EXISTS chat (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            timestamp TEXT,
            username TEXT,
            session_id TEXT,
            role TEXT,
            content TEXT
        )
    ''')
    c.execute('''
        CREATE TABLE IF NOT EXISTS users (
            username TEXT PRIMARY KEY,
            passcode TEXT
        )
    ''')
    conn.commit()
    conn.close()

def register_user(username: str, passcode: str):
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    hashed_pw = bcrypt.hashpw(passcode.encode(), bcrypt.gensalt()).decode()
    try:
        c.execute("INSERT INTO users (username, passcode) VALUES (?, ?)", (username, hashed_pw))
        conn.commit()
    except sqlite3.IntegrityError:
        pass
    finally:
        conn.close()

def authenticate_user(username: str, passcode: str) -> bool:
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute("SELECT passcode FROM users WHERE username = ?", (username,))
    row = c.fetchone()
    conn.close()
    if not row:
        return False
    stored_hash = row[0].encode()
    return bcrypt.checkpw(passcode.encode(), stored_hash)

def save_message(username: str, session_id: str, role: str, content: str):
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute("INSERT INTO chat (timestamp, username, session_id, role, content) VALUES (?, ?, ?, ?, ?)", 
              (datetime.now().isoformat(), username, session_id, role, content))
    conn.commit()
    conn.close()

def load_history(username: str, session_id: str, limit: int = 100):
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute("SELECT timestamp, role, content FROM chat WHERE username = ? AND session_id = ? ORDER BY id DESC LIMIT ?", 
              (username, session_id, limit))
    rows = c.fetchall()
    conn.close()
    return rows[::-1]

def get_all_sessions_for_user(username: str):
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute("SELECT DISTINCT session_id FROM chat WHERE username = ? ORDER BY id DESC", (username,))
    sessions = [row[0] for row in c.fetchall()]
    conn.close()
    return sessions

def load_history_by_session(session_id: str):
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute("SELECT timestamp, role, content FROM chat WHERE session_id = ? ORDER BY id ASC", (session_id,))
    rows = c.fetchall()
    conn.close()
    return rows

def export_session_to_csv(session_id: str) -> bytes:
    conn = sqlite3.connect(DB_PATH)
    df = pd.read_sql_query(
        "SELECT timestamp, role, content FROM chat WHERE session_id = ? ORDER BY id ASC", 
        conn, params=(session_id,)
    )
    conn.close()
    return df.to_csv(index=False).encode("utf-8")

def export_session_to_text(session_id: str) -> str:
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute("SELECT timestamp, role, content FROM chat WHERE session_id = ? ORDER BY id ASC", (session_id,))
    messages = c.fetchall()
    conn.close()
    return "\n\n".join(f"[{t}] {role.capitalize()}: {msg}" for t, role, msg in messages)
