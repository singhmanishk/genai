import streamlit as st
from langgraph_bot import build_graph
from chat_db import init_db, register_user, authenticate_user, save_message, load_history, get_all_sessions_for_user, export_session_to_csv, export_session_to_text, load_history_by_session
import uuid

graph = build_graph()
st.set_page_config(page_title="Jira Chatbot", layout="wide")
init_db()

if "username" not in st.session_state:
    st.session_state.username = None
    st.session_state.session_id = None

if st.session_state.username is None:
    st.sidebar.subheader("🔐 Login or Register")
    login_mode = st.sidebar.radio("Select", ["Login", "Register"], horizontal=True)
    input_username = st.sidebar.text_input("👤 Username")
    input_passcode = st.sidebar.text_input("🔑 Passcode", type="password")
    if st.sidebar.button("Start Chat"):
        if login_mode == "Register":
            register_user(input_username, input_passcode)
            st.success("✅ Registered successfully. Please log in.")
            st.stop()
        elif login_mode == "Login":
            if authenticate_user(input_username, input_passcode):
                st.session_state.username = input_username
                st.session_state.session_id = str(uuid.uuid4())
                st.success("✅ Login successful!")
            else:
                st.error("❌ Incorrect credentials.")
                st.stop()
    st.stop()

if "messages" not in st.session_state:
    st.session_state.messages = []

st.sidebar.title("🛠️ Jira Chatbot")
st.sidebar.markdown("Ask about a Jira issue using its key (e.g., `BUG-123`, `PROJ-45`).")

with st.sidebar.expander("📂 My Past Sessions", expanded=False):
    all_sessions = get_all_sessions_for_user(st.session_state.username)
    selected_session = st.selectbox("Select session to view", all_sessions if all_sessions else ["(none)"])
    if selected_session and selected_session != "(none)":
        logs = load_history_by_session(selected_session)
        for t, role, msg in logs:
            st.markdown(f"**[{role}]** {msg}")
        st.markdown("---")
        col1, col2 = st.columns(2)
        with col1:
            st.download_button("📄 Export CSV", export_session_to_csv(selected_session), file_name=f"{selected_session}.csv", mime="text/csv")
        with col2:
            st.download_button("📝 Export TXT", export_session_to_text(selected_session), file_name=f"{selected_session}.txt", mime="text/plain")

st.title("🤖 Jira Chatbot")

for msg in st.session_state.messages:
    with st.chat_message(msg["role"]):
        st.markdown(msg["content"])

user_input = st.chat_input("Ask me about a Jira issue...")

if user_input:
    st.session_state.messages.append({"role": "user", "content": user_input})
    with st.chat_message("user"):
        st.markdown(user_input)
    with st.spinner("Fetching from Jira..."):
        state = {
            "user_input": user_input,
            "issue_key": None,
            "raw_data": None,
            "answer": None
        }
        result = graph.invoke(state)
        answer = result.get("answer", "Something went wrong.")
        st.session_state.messages.append({"role": "assistant", "content": answer})
        save_message(st.session_state.username, st.session_state.session_id, "user", user_input)
        save_message(st.session_state.username, st.session_state.session_id, "assistant", answer)
        with st.chat_message("assistant"):
            st.markdown(answer)
