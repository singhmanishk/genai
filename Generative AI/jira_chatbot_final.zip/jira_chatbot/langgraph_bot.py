import os
from dotenv import load_dotenv
from jira import JIRA
from langchain.chat_models import ChatOpenAI
from langchain.prompts import PromptTemplate
from langchain.chains import LLMChain
from langgraph.graph import StateGraph, END
import re
from typing import TypedDict, Optional

load_dotenv()

jira = JIRA(
    server=os.getenv("JIRA_SERVER"),
    basic_auth=(os.getenv("JIRA_EMAIL"), os.getenv("JIRA_API_TOKEN"))
)
llm = ChatOpenAI(openai_api_key=os.getenv("OPENAI_API_KEY"), model="gpt-4")

class JiraState(TypedDict):
    user_input: str
    issue_key: Optional[str]
    raw_data: Optional[str]
    answer: Optional[str]

def extract_issue_key(state: JiraState):
    match = re.search(r"[A-Z]+-\d+", state["user_input"])
    state["issue_key"] = match.group() if match else None
    return state

def fetch_issue_data(state: JiraState):
    key = state.get("issue_key")
    if not key:
        state["raw_data"] = "No valid Jira issue key found."
        return state
    try:
        issue = jira.issue(key)
        data = f"Issue: {issue.key}\nSummary: {issue.fields.summary}\nStatus: {issue.fields.status.name}\nAssignee: {issue.fields.assignee.displayName if issue.fields.assignee else 'Unassigned'}\nPriority: {issue.fields.priority.name}"
        state["raw_data"] = data
    except Exception as e:
        state["raw_data"] = f"Error fetching issue: {str(e)}"
    return state

template = PromptTemplate.from_template("""
You are a Jira expert assistant. Use the Jira issue data below to answer the user's question.

User question: {question}
Jira data:
{data}

Answer:
""")
qa_chain = LLMChain(llm=llm, prompt=template)

def generate_answer(state: JiraState):
    result = qa_chain.run({
        "question": state["user_input"],
        "data": state["raw_data"]
    })
    state["answer"] = result.strip()
    return state

def build_graph():
    builder = StateGraph(JiraState)
    builder.add_node("ExtractKey", extract_issue_key)
    builder.add_node("FetchData", fetch_issue_data)
    builder.add_node("AnswerWithLLM", generate_answer)
    builder.set_entry_point("ExtractKey")
    builder.add_edge("ExtractKey", "FetchData")
    builder.add_edge("FetchData", "AnswerWithLLM")
    builder.add_edge("AnswerWithLLM", END)
    return builder.compile()
