from langchain.tools import tool

@tool
def get_jira_issue(issue_id: str) -> str:
    return f"[Jira] Issue {issue_id}: (dummy response)"

@tool
def create_jira_ticket(description: str) -> str:
    return f"[Jira] Created ticket with description: {description}"
