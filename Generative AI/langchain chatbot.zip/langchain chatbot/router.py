from langchain.embeddings import OpenAIEmbeddings
from langchain.vectorstores import FAISS
from langchain.schema import Document

embedding_model = OpenAIEmbeddings()

DOCS = [
    Document(page_content="jira issue bug ticket epic", metadata={"route": "jira"}),
    Document(page_content="confluence wiki page knowledge doc", metadata={"route": "confluence"}),
    Document(page_content="general purpose conversation ai", metadata={"route": "general"})
]

vectorstore = FAISS.from_documents(DOCS, embedding_model)

def semantic_route(user_input: str) -> str:
    results = vectorstore.similarity_search(user_input, k=1)
    return results[0].metadata["route"]
