from langchain.agents import initialize_agent
from langchain.chat_models import ChatOpenAI
from tools.jira_tools import get_jira_issue, create_jira_ticket
from tools.confluence_tools import get_confluence_page, search_confluence_docs

llm = ChatOpenAI(model="gpt-4", temperature=0)

jira_agent = initialize_agent(
    tools=[get_jira_issue, create_jira_ticket],
    llm=llm,
    agent_type="chat-zero-shot-react-description",
    verbose=True
)

confluence_agent = initialize_agent(
    tools=[get_confluence_page, search_confluence_docs],
    llm=llm,
    agent_type="chat-zero-shot-react-description",
    verbose=True
)
