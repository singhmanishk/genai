from router import semantic_route
from agents import jira_agent, confluence_agent, llm

def handle_user_query(user_input: str) -> str:
    route = semantic_route(user_input)
    if route == "jira":
        return jira_agent.run(user_input)
    elif route == "confluence":
        return confluence_agent.run(user_input)
    else:
        return llm.predict(user_input)
