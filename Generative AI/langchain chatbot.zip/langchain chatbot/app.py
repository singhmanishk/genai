import streamlit as st
from db import init_db, create_session, list_sessions, save_message, get_messages
from chatbot import handle_user_query

st.set_page_config(page_title="Jira + Confluence Chatbot", layout="wide")
st.title("📌 Jira + Confluence Chatbot")

init_db()
username = st.sidebar.text_input("Username", value="guest")

# List & select sessions
sessions = list_sessions(username)
session_labels = [f"{sid} @ {ts[:16].replace('T', ' ')}" for sid, ts in sessions]
selected = st.sidebar.selectbox("Select session", ["Start new session"] + session_labels)

# Session handling
if "session_id" not in st.session_state or selected == "Start new session":
    st.session_state.session_id = create_session(username)
    st.session_state.chat_history = []
else:
    sid = int(selected.split(" @ ")[0])
    st.session_state.session_id = sid
    st.session_state.chat_history = get_messages(sid)

# Display history
for role, msg in st.session_state.chat_history:
    st.chat_message(role).write(msg)

# Chat input
user_input = st.chat_input("Ask about Jira, Confluence or anything else...")

if user_input:
    save_message(st.session_state.session_id, "user", user_input)
    st.chat_message("user").write(user_input)

    response = handle_user_query(user_input)

    save_message(st.session_state.session_id, "assistant", response)
    st.chat_message("assistant").write(response)

    st.session_state.chat_history.append(("user", user_input))
    st.session_state.chat_history.append(("assistant", response))
