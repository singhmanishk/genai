from langchain.tools import tool

@tool
def get_confluence_page(title: str) -> str:
    return f"[Confluence] Page '{title}' content (dummy)."

@tool
def search_confluence_docs(query: str) -> str:
    return f"[Confluence] Search results for: {query}"
