import sqlite3
from datetime import datetime

DB_FILE = "chat_history.db"

def init_db():
    conn = sqlite3.connect(DB_FILE)
    c = conn.cursor()
    c.execute('''CREATE TABLE IF NOT EXISTS sessions (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT,
        created_at TEXT
    )''')
    c.execute('''CREATE TABLE IF NOT EXISTS messages (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        session_id INTEGER,
        role TEXT,
        message TEXT,
        timestamp TEXT
    )''')
    conn.commit()
    conn.close()

def create_session(username):
    conn = sqlite3.connect(DB_FILE)
    c = conn.cursor()
    ts = datetime.utcnow().isoformat()
    c.execute("INSERT INTO sessions (username, created_at) VALUES (?, ?)", (username, ts))
    session_id = c.lastrowid
    conn.commit()
    conn.close()
    return session_id

def list_sessions(username):
    conn = sqlite3.connect(DB_FILE)
    c = conn.cursor()
    c.execute("SELECT id, created_at FROM sessions WHERE username = ? ORDER BY id DESC", (username,))
    return c.fetchall()

def save_message(session_id, role, message):
    conn = sqlite3.connect(DB_FILE)
    c = conn.cursor()
    c.execute("INSERT INTO messages (session_id, role, message, timestamp) VALUES (?, ?, ?, ?)",
              (session_id, role, message, datetime.utcnow().isoformat()))
    conn.commit()
    conn.close()

def get_messages(session_id):
    conn = sqlite3.connect(DB_FILE)
    c = conn.cursor()
    c.execute("SELECT role, message FROM messages WHERE session_id = ? ORDER BY id", (session_id,))
    return c.fetchall()
