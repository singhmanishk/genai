"""
ChatGPT‑like Streamlit UI that uses the LangGraph agent instead of a raw
OpenAI completion.   Run with:
    streamlit run chat_ui.py
requirements:
    pip install streamlit openai langchain langgraph yfinance
"""

import streamlit as st
from agent_graph import run_agent  # ← our LangGraph helper

st.set_page_config(page_title="LangGraph Chatbot", page_icon="📈")
st.title("📈 LangGraph‑Powered Chatbot")

if "messages" not in st.session_state:
    st.session_state.messages = [
        {"role": "assistant",
         "content": "Hi there 👋 — ask me anything (stock prices included)."}
    ]

for m in st.session_state.messages:
    with st.chat_message(m["role"]):
        st.markdown(m["content"])

if prompt := st.chat_input("Type your message and press Enter …"):
    st.session_state.messages.append({"role": "user", "content": prompt})
    with st.chat_message("user"):
        st.markdown(prompt)

    with st.chat_message("assistant"):
        placeholder = st.empty()
        placeholder.markdown("…")

        answer = run_agent(st.session_state.messages)

        placeholder.markdown(answer)

    st.session_state.messages.append({"role": "assistant", "content": answer})
