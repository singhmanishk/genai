import requests
from typing import List, Dict

# Placeholder config
JIRA_BASE_URL = "https://your-domain.atlassian.net"
JIRA_API_TOKEN = "your-api-token"
JIRA_EMAIL = "your-email@example.com"

def search_issues(query: str) -> List[Dict]:
    # Replace with actual API call to Jira
    print(f"Mock search for issues with query: {query}")
    return [
        {"key": "PROJ-101", "summary": "Login fails for user", "description": "401 error on login"},
        {"key": "PROJ-102", "summary": "Dashboard UI glitch", "description": "Buttons overlap in Firefox"}
    ]

def get_issue(issue_key: str) -> Dict:
    print(f"Mock get issue: {issue_key}")
    return {"key": issue_key, "summary": "Mock issue", "description": "Issue details"}