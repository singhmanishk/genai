from langgraph.graph import StateGraph, END
from chat.state import State
from chat.sqlite_wrapper import save_state_to_db
from chat.semantic_search import search_similar_issues

def llm_response(context: str, question: str) -> str:
    return f"Based on context:\n\n{context}\n\nAnswer to: {question}"

def semantic_routing_node(state: State) -> str:
    question = state["input"]
    matches = search_similar_issues(question)
    if matches:
        context = "\n\n".join([m["content"] for m in matches])
        state["output"] = llm_response(context, question)
    else:
        state["output"] = "No relevant Jira issues found. Please rephrase your question."
    state["messages"].append({"role": "assistant", "content": state["output"]})
    return END

def create_chat_graph():
    builder = StateGraph(State)
    builder.add_node("semantic_router", semantic_routing_node)
    builder.set_entry_point("semantic_router")
    builder.set_finish_point(END)
    return builder.compile()