from typing import TypedDict, List, Optional
from langgraph.graph import add_messages

class State(TypedDict):
    input: Optional[str]
    output: Optional[str]
    messages: List[dict]
    summary: Optional[str]
    summary_count: int

add_messages_reducer = add_messages(lambda state: state["messages"])