from typing import List, Dict
from langchain.embeddings import HuggingFaceEmbeddings
from langchain.vectorstores import Chroma
import chromadb

embedding_model = HuggingFaceEmbeddings(model_name="sentence-transformers/all-MiniLM-L6-v2")
chroma_client = chromadb.Client()
vectorstore = Chroma(collection_name="jira_issues", embedding_function=embedding_model, client=chroma_client)

def index_issues_to_chroma(issues: List[Dict]):
    texts = []
    metadatas = []
    for issue in issues:
        text = issue["summary"] + "\n" + issue.get("description", "")
        texts.append(text)
        metadatas.append({"key": issue["key"]})
    vectorstore.add_texts(texts, metadatas)

def search_similar_issues(question: str, k: int = 3) -> List[Dict]:
    results = vectorstore.similarity_search(question, k=k)
    return [{"content": doc.page_content, **doc.metadata} for doc in results]