import sqlite3
import json
from chat.state import State

def save_state_to_db(session_id: str, state: State):
    conn = sqlite3.connect("chat_memory.db")
    cursor = conn.cursor()
    cursor.execute(
        "CREATE TABLE IF NOT EXISTS chat_memory (session_id TEXT PRIMARY KEY, state_json TEXT)"
    )
    cursor.execute("REPLACE INTO chat_memory (session_id, state_json) VALUES (?, ?)", 
                   (session_id, json.dumps(state)))
    conn.commit()
    conn.close()

def load_state_from_db(session_id: str) -> State:
    conn = sqlite3.connect("chat_memory.db")
    cursor = conn.cursor()
    cursor.execute("SELECT state_json FROM chat_memory WHERE session_id = ?", (session_id,))
    row = cursor.fetchone()
    conn.close()
    if row:
        return json.loads(row[0])
    else:
        return {"input": None, "output": None, "messages": [], "summary": None, "summary_count": 0}