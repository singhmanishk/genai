import streamlit as st
from chat.state import State
from chat.sqlite_wrapper import load_state_from_db, save_state_to_db
from chat.graph import create_chat_graph

graph = create_chat_graph()

st.set_page_config(page_title="Jira Chatbot", layout="wide")
st.title("🧠 Jira Chatbot")

session_id = st.sidebar.text_input("Session ID", value="default_session")
if "state" not in st.session_state:
    st.session_state.state = load_state_from_db(session_id)

chat_state: State = st.session_state.state

for msg in chat_state["messages"]:
    role = msg["role"]
    st.chat_message(role).markdown(msg["content"])

user_input = st.chat_input("Ask something about Jira...")
if user_input:
    chat_state["input"] = user_input
    chat_state["messages"].append({"role": "user", "content": user_input})
    output_state = graph.invoke(chat_state)
    st.session_state.state = output_state
    save_state_to_db(session_id, output_state)
    st.rerun()