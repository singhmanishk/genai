
import requests
from bs4 import BeautifulSoup
from langchain_core.documents import Document
from langchain.text_splitter import HTMLHeaderTextSplitter
import os

def fetch_and_split_confluence_docs():
    base_url = os.getenv("CONFLUENCE_BASE_URL")
    email = os.getenv("CONFLUENCE_EMAIL")
    token = os.getenv("CONFLUENCE_API_TOKEN")

    auth = (email, token)
    headers = {"Accept": "application/json"}

    page_ids = ["123456", "654321"]  # Replace with dynamic fetch if needed
    all_docs = []

    for pid in page_ids:
        url = f"{base_url}/rest/api/content/{pid}?expand=body.storage"
        response = requests.get(url, auth=auth, headers=headers)
        html = response.json()["body"]["storage"]["value"]
        soup = BeautifulSoup(html, "html.parser")
        raw_html = str(soup)

        splitter = HTMLHeaderTextSplitter(headers_to_split_on=[("h1", "Header")])
        docs = splitter.split_text(raw_html)
        all_docs.extend([Document(page_content=d.content, metadata={"page_id": pid}) for d in docs])

    return all_docs
