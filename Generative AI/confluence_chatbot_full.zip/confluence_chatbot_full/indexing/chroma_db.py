
from langchain.embeddings import OpenAIEmbeddings
from langchain.vectorstores import Chroma
import os

def save_to_chroma(docs):
    db = Chroma.from_documents(
        documents=docs,
        embedding=OpenAIEmbeddings(),
        persist_directory="chromadb"
    )
    db.persist()

def load_chroma():
    return Chroma(
        persist_directory="chromadb",
        embedding_function=OpenAIEmbeddings()
    )
