
# chat/state.py

from typing import List, Dict, Union
from langchain.chat_models import ChatOpenAI

class State(dict):
    """
    A state container for LangGraph with support for chat memory and reducers.
    """

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.setdefault("messages", [])
        self.setdefault("input", "")
        self.setdefault("output", "")
        self.setdefault("auto_summarize", True)  # Toggle for automatic summarization
        self.setdefault("summary_turns", 6)       # How many recent turns to keep

    def add_messages(self, new_messages: Union[Dict, List[Dict]]):
        if isinstance(new_messages, dict):
            new_messages = [new_messages]
        self["messages"].extend(new_messages)
        if self.get("auto_summarize", True) and len(self["messages"]) > 15:
            self.summarize_memory(self["summary_turns"])

    def set_input(self, text: str):
        self["input"] = text

    def set_output(self, text: str):
        self["output"] = text
        self.add_messages({"role": "bot", "content": text})

    def add_user_input(self, text: str):
        self.set_input(text)
        self.add_messages({"role": "user", "content": text})

    def clear(self):
        self["messages"] = []
        self["input"] = ""
        self["output"] = ""

    def summarize_memory(self, max_turns: int = 6):
        if len(self["messages"]) <= max_turns:
            return

        summary_llm = ChatOpenAI(temperature=0)
        summary_text = summary_llm.invoke(
            "Summarize the following conversation:
" +
            "\n".join([f"{m['role']}: {m['content']}" for m in self["messages"][:-max_turns]])
        ).content

        recent = self["messages"][-max_turns:]
        self["messages"] = [
            {"role": "system", "content": f"Conversation summary:\n{summary_text}"}
        ] + recent
