
from indexing.fetch_and_split import fetch_and_split_confluence_docs
from indexing.chroma_db import save_to_chroma

def refresh_index():
    docs = fetch_and_split_confluence_docs()
    save_to_chroma(docs)
    return "✅ Index refreshed successfully."
