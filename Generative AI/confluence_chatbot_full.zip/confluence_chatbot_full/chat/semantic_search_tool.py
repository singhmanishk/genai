
from indexing.chroma_db import load_chroma

def semantic_search_confluence(query):
    chroma = load_chroma()
    results = chroma.similarity_search(query, k=1)
    if results:
        return {"found": True, "answer": results[0].page_content}
    return {"found": False}
