
from langgraph.graph import StateGraph, END
from chat.state import State
from chat.semantic_search_tool import semantic_search_confluence
from chat.refresh_tool import refresh_index
from langchain.chat_models import ChatOpenAI

def router_node(state: State):
    if state["input"].strip() == "/refresh":
        return {"route": "refresh"}
    return {"route": "semantic"}

def semantic_node(state: State):
    result = semantic_search_confluence(state["input"])
    if result["found"]:
        llm = ChatOpenAI()
        prompt = f"Use the following context to answer the question:\n\n{result['context']}\n\nQuestion: {state['input']}"
        response = llm.invoke(prompt).content
        state.set_output(response)
        return state
    return {"route": "fallback"}

def fallback_node(state: State):
    llm = ChatOpenAI()
    output = llm.invoke(state["input"]).content
    state.set_output(output)
    return state

def refresh_node(state: State):
    msg = refresh_index()
    state.set_output(msg)
    return state

builder = StateGraph(State)
builder.add_node("router", router_node)
builder.add_node("semantic", semantic_node)
builder.add_node("fallback", fallback_node)
builder.add_node("refresh", refresh_node)

builder.set_entry_point("router")
builder.add_conditional_edges("router", lambda x: x["route"], {
    "semantic": "semantic",
    "refresh": "refresh"
})
builder.add_edge("semantic", "fallback")
builder.add_edge("refresh", END)
builder.add_edge("fallback", END)

chat_graph = builder.compile()
