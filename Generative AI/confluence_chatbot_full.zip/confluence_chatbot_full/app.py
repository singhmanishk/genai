
import streamlit as st
from chat.state import State
from chat.chat_graph import chat_graph

st.title("📘 Confluence Assistant")
if "chat_state" not in st.session_state:
    st.session_state.chat_state = State()

user_input = st.chat_input("Ask me something...")
if user_input:
    state = st.session_state.chat_state
    state.add_user_input(user_input)
    result = chat_graph.invoke(state)
    st.session_state.chat_state = result

for msg in st.session_state.chat_state["messages"]:
    with st.chat_message(msg["role"]):
        st.markdown(msg["content"])
