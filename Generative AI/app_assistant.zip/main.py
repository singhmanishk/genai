from app_assistant.chat.chat_engine import ChatEngine

def main():
    chat = ChatEngine()
    chat.run_full_flow()

if __name__ == "__main__":
    main()
