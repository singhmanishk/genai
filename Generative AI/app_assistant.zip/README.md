# App Assistant

A modular Python assistant with chat, indexing, and scheduling capabilities.