
from langgraph.graph import StateGraph, END
from langchain_core.messages import HumanMessage, AIMessage, BaseMessage
from langchain.chat_models import ChatOpenAI
from langchain.memory import ConversationBufferMemory
from langchain_core.runnables import RunnableLambda
from typing import TypedDict, List
from sqlite_memory import load_messages, save_message, init_db
from memory_summary import generate_memory_summary
import pandas as pd

class ChatState(TypedDict):
    messages: List[BaseMessage]
    user_id: str

init_db()
llm = ChatOpenAI(model="gpt-4")

def lookup_order_tool(input: ChatState) -> ChatState:
    message = input["messages"][-1].content.lower()
    df = pd.read_csv("data/orders.csv")
    for row in df.itertuples():
        if str(row.order_id) in message:
            return {"messages": input["messages"] + [AIMessage(content=f"Order {row.order_id} status is {row.status}")], "user_id": input["user_id"]}
    return {"messages": input["messages"] + [AIMessage(content="Order not found.")], "user_id": input["user_id"]}

def route(input: ChatState) -> str:
    content = input["messages"][-1].content.lower()
    if "payment" in content:
        return "payment"
    elif "order" in content:
        return "order"
    return "default"

def get_memory(user_id: str) -> ConversationBufferMemory:
    mem = ConversationBufferMemory(return_messages=True, memory_key="messages")
    mem.chat_memory.messages = load_messages(user_id)
    return mem

def payment_node(input: ChatState) -> ChatState:
    user_id = input["user_id"]
    memory = get_memory(user_id)
    messages = memory.chat_memory.messages + input["messages"]
    output = llm.invoke(messages)
    save_message(user_id, input["messages"][-1])
    save_message(user_id, output)
    return {"messages": [*input["messages"], output], "user_id": user_id}

def order_node(input: ChatState) -> ChatState:
    user_id = input["user_id"]
    memory = get_memory(user_id)
    tool_result = lookup_order_tool(input)
    messages = memory.chat_memory.messages + tool_result["messages"]
    output = llm.invoke(messages)
    save_message(user_id, input["messages"][-1])
    save_message(user_id, output)
    return {"messages": [*input["messages"], output], "user_id": user_id}

def default_node(input: ChatState) -> ChatState:
    user_id = input["user_id"]
    memory = get_memory(user_id)
    messages = memory.chat_memory.messages + input["messages"]
    output = llm.invoke(messages)
    save_message(user_id, input["messages"][-1])
    save_message(user_id, output)
    return {"messages": [*input["messages"], output], "user_id": user_id}

workflow = StateGraph(ChatState)
workflow.add_node("router", RunnableLambda(route))
workflow.add_node("payment", payment_node)
workflow.add_node("order", order_node)
workflow.add_node("default", default_node)
workflow.set_entry_point("router")
workflow.add_conditional_edges("router", route, {
    "payment": "payment",
    "order": "order",
    "default": "default"
})
workflow.add_edge("payment", END)
workflow.add_edge("order", END)
workflow.add_edge("default", END)
app = workflow.compile()
