
import sqlite3
from langchain_core.messages import HumanMessage, AIMessage, BaseMessage

DB_FILE = "chat_memory.db"

def init_db():
    conn = sqlite3.connect(DB_FILE)
    c = conn.cursor()
    c.execute("""
    CREATE TABLE IF NOT EXISTS messages (
        user_id TEXT,
        role TEXT,
        content TEXT,
        timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
    )
    """)
    conn.commit()
    conn.close()

def save_message(user_id: str, message: BaseMessage):
    conn = sqlite3.connect(DB_FILE)
    c = conn.cursor()
    role = "human" if isinstance(message, HumanMessage) else "ai"
    c.execute("INSERT INTO messages (user_id, role, content) VALUES (?, ?, ?)",
              (user_id, role, message.content))
    conn.commit()
    conn.close()

def load_messages(user_id: str) -> list[BaseMessage]:
    conn = sqlite3.connect(DB_FILE)
    c = conn.cursor()
    c.execute("SELECT role, content FROM messages WHERE user_id = ? ORDER BY timestamp", (user_id,))
    rows = c.fetchall()
    conn.close()
    messages = []
    for role, content in rows:
        if role == "human":
            messages.append(HumanMessage(content=content))
        elif role == "ai":
            messages.append(AIMessage(content=content))
    return messages

def delete_user_memory(user_id: str):
    conn = sqlite3.connect(DB_FILE)
    c = conn.cursor()
    c.execute("DELETE FROM messages WHERE user_id = ?", (user_id,))
    conn.commit()
    conn.close()

def get_messages_by_user(user_id: str):
    conn = sqlite3.connect(DB_FILE)
    c = conn.cursor()
    c.execute("SELECT rowid, role, content, timestamp FROM messages WHERE user_id = ? ORDER BY timestamp", (user_id,))
    results = c.fetchall()
    conn.close()
    return results

def delete_message_by_id(msg_id: int):
    conn = sqlite3.connect(DB_FILE)
    c = conn.cursor()
    c.execute("DELETE FROM messages WHERE rowid = ?", (msg_id,))
    conn.commit()
    conn.close()
