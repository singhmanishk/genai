
from langchain_core.prompts import PromptTemplate
from langchain.chat_models import ChatOpenAI
from langchain_core.messages import BaseMessage, HumanMessage, AIMessage

llm = ChatOpenAI(model="gpt-4")

def generate_memory_summary(messages: list[BaseMessage]) -> str:
    prompt = PromptTemplate.from_template("""
    You are a summarization assistant.
    Summarize this user’s chat history in 5 concise bullet points.

    {history}
    """)
    history_text = "\n".join(
        f"{'User' if isinstance(m, HumanMessage) else 'Bot'}: {m.content}" for m in messages
    )
    chain = prompt | llm
    result = chain.invoke({"history": history_text})
    return result.content
