
# Custom Branding Section
st.markdown("""
<style>
    .branding-banner {
        background-color: #003366;
        padding: 1rem;
        border-radius: 10px;
        margin-bottom: 2rem;
        color: white;
        text-align: center;
    }
    .branding-logo {
        height: 50px;
        margin-right: 10px;
        vertical-align: middle;
    }
</style>
<div class="branding-banner">
    <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/5/58/ChatGPT_logo.svg/512px-ChatGPT_logo.svg.png"
         class="branding-logo" />
    <span style="font-size: 1.5rem;">MyCompany AI Assistant</span>
</div>
""", unsafe_allow_html=True)

import streamlit as st
import uuid
import json
import datetime
from langchain_core.messages import HumanMessage, AIMessage
from chatbot_graph import app
from sqlite_memory import (
    delete_user_memory, get_messages_by_user,
    delete_message_by_id, load_messages
)
from memory_summary import generate_memory_summary

# Email login
st.set_page_config(page_title="Chatbot with Email Login")
st.title("🔐 Login to Chat")

if "user_email" not in st.session_state:
    email = st.text_input("Enter your email to start:", key="email_input")
    if st.button("Login") and email:
        st.session_state.user_email = email.strip().lower()
        st.rerun()
    st.stop()

user_id = st.session_state.user_email
st.success(f"Logged in as: {user_id}")

# Clear memory
if st.button("🧹 Clear My Chat Memory"):
    delete_user_memory(user_id)
    st.session_state.chat_history = []
    st.rerun()

# Chat UI
if "chat_history" not in st.session_state:
    st.session_state.chat_history = []

user_input = st.chat_input("Ask about Payment or Order")

if user_input:
    messages = st.session_state.chat_history + [HumanMessage(content=user_input)]
    response = app.invoke({"messages": messages, "user_id": user_id})
    st.session_state.chat_history = response["messages"]

for msg in st.session_state.chat_history:
    if isinstance(msg, HumanMessage):
        st.chat_message("user").write(msg.content)
    elif isinstance(msg, AIMessage):
        st.chat_message("assistant").write(msg.content)

# Dashboard
with st.expander("📊 My Chat Dashboard", expanded=False):
    st.markdown("### 📋 My Messages (Delete or Filter)")

    all_msgs = get_messages_by_user(user_id)

    # Filter by date
    date_filter = st.date_input("Filter by date:", value=None)
    filtered_msgs = []
    for msg in all_msgs:
        msg_id, role, content, timestamp = msg
        if date_filter and not timestamp.startswith(str(date_filter)):
            continue
        filtered_msgs.append(msg)

    for msg_id, role, content, timestamp in filtered_msgs:
        with st.container():
            col1, col2 = st.columns([6, 1])
            with col1:
                st.markdown(f"**{role.upper()}** ({timestamp})

{content}")
            with col2:
                if st.button("❌", key=f"delete_{msg_id}"):
                    delete_message_by_id(msg_id)
                    st.success("Message deleted.")
                    st.rerun()

    st.divider()
    st.markdown("### 🧠 Chat Summary")
    if st.button("Summarize My Chat"):
        memory_msgs = load_messages(user_id)
        summary = generate_memory_summary(memory_msgs)
        st.markdown(summary)

    st.divider()
    st.markdown("### 📥 Download")
    col1, col2 = st.columns(2)
    st.download_button("📄 Download .txt", "\n".join(f"{r}: {c}" for _, r, c, _ in filtered_msgs),
                       file_name=f"{user_id}_chat.txt")
    st.download_button("🧾 Download .json", json.dumps([
        {"role": r, "content": c, "timestamp": t} for _, r, c, t in filtered_msgs
    ]), file_name=f"{user_id}_chat.json")

    st.markdown("### 🔢 Stats")
    st.write(f"🗨️ Total messages: {len(all_msgs)}")
    st.write(f"👤 User: `{user_id}`")
